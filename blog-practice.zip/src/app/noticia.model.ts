export interface Noticia {
  titulo: string;
  imagenUrl: string;
  texto: string;
  fecha: string;
}

